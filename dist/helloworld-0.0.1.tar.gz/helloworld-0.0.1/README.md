# Pacote teste Pip

para instalar

```
pip install -e .[dev]
```